#define UTS_RELEASE "6.7.9-rt-amd64"
