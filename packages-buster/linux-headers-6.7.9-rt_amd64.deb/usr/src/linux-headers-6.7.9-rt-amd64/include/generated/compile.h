#define UTS_MACHINE		"x86_64"
#define LINUX_COMPILE_BY	"debian-kernel"
#define LINUX_COMPILE_HOST	"lists.debian.org"
#define LINUX_COMPILER		"x86_64-linux-gnu-gcc-13 (Debian 13.2.0-18) 13.2.0, GNU ld (GNU Binutils for Debian) 2.42"
